const mongoose =
    require("mongoose");

const Order =
    require("../../models/Order");

const CustomerReturn =
    require(
        "../../models/CustomerReturn"
    );

const ROLES =
    require("../../constants/roles");

const generateReturnNumber =
    require("./generateReturnNumber");

const validateReturn =
    require("./validateReturn");


const createCustomerReturn =
    async ({
        orderNumber,
        items,
        reason,
        notes = "",
        user,
    }) => {

        const session =
            await mongoose.startSession();


        try {

            session.startTransaction();


            const order =
                await Order.findOne({
                    orderNumber,
                })
                    .session(session);


            if (!order) {

                throw new Error(
                    "Order not found."
                );

            }


            if (
                user.role !==
                    ROLES.ADMIN &&
                order.customer.user
                    ?.toString() !==
                    user._id.toString()
            ) {

                throw new Error(
                    "You are not authorized to return this order."
                );

            }


            validateReturn({
                order,
                items,
                reason,
            });


            const orderItemMap =
                new Map(
                    order.items.map(
                        item => [
                            item.product
                                .toString(),
                            item,
                        ]
                    )
                );


            const returnItems =
                items.map(item => {

                    const orderItem =
                        orderItemMap.get(
                            item.product
                                .toString()
                        );


                    return {

                        product:
                            orderItem
                                .product,

                        title:
                            orderItem
                                .title,

                        sku:
                            orderItem.sku,

                        quantity:
                            item.quantity,

                        unitPrice:
                            orderItem
                                .pricing
                                .finalPrice,

                    };

                });


            const returnNumber =
                await generateReturnNumber(
                    session
                );


            const [customerReturn] =
                await CustomerReturn.create(
                    [
                        {

                            returnNumber,

                            order:
                                order._id,

                            orderNumber:
                                order.orderNumber,

                            customer:
                                order.customer
                                    .user,

                            items:
                                returnItems,

                            reason:
                                reason.trim(),

                            notes,

                        },
                    ],
                    {
                        session,
                    }
                );


            await session
                .commitTransaction();


            return customerReturn;

        } catch (error) {

            await session
                .abortTransaction();

            throw error;

        } finally {

            await session
                .endSession();

        }

    };


module.exports =
    createCustomerReturn;